using Microsoft.Extensions.Options;
using Optimalizapp.Models;
using Optimalizapp.Services;

var builder = WebApplication.CreateBuilder(args);

// Dodajemy konfiguracj� MongoDB
builder.Services.Configure<MongoDbSettings>(builder.Configuration.GetSection("MongoDB"));
builder.Services.AddSingleton<UserService>();

// Dodajemy MVC (kontrolery i widoki)
builder.Services.AddControllersWithViews();

var app = builder.Build();

// Obs�uga b��d�w w trybie produkcyjnym
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Middleware
app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.UseAuthorization();

// Ustawienie domy�lnej trasy
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();


