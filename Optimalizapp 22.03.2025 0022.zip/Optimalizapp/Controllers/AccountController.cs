﻿using Microsoft.AspNetCore.Mvc;
using Optimalizapp.Models;
using Optimalizapp.Services;
using System.Threading.Tasks;

namespace Optimalizapp.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserService _userService;

        public AccountController(UserService userService)
        {
            _userService = userService;
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(string username, string password)
        {
            var existingUser = await _userService.GetUserByUsernameAsync(username);
            if (existingUser != null)
            {
                ViewBag.ErrorMessage = "Nazwa użytkownika jest już zajęta.";
                return View();
            }

            var user = new User
            {
                Username = username,
                PasswordHash = password
            };

            await _userService.CreateUserAsync(user);
            return RedirectToAction("Login", "Home");
        }
    }
}
