﻿using System.ComponentModel.DataAnnotations;

public class EditProfileViewModel
{
    [Required]
    public string Username { get; set; }

    [Required, EmailAddress]
    public string Email { get; set; }

    public string FirstName { get; set; }
    public string LastName { get; set; }
}
