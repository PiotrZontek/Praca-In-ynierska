﻿using Microsoft.AspNetCore.Mvc;
using Optimalizapp.Models;
using Optimalizapp.Services;
using System.Threading.Tasks;

namespace Optimalizapp.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserService _userService;

        public AccountController(UserService userService)
        {
            _userService = userService;
        }

        public IActionResult Register()
        {
            return View();
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            TempData["LogoutMessage"] = "Wylogowano pomyślnie.";
            return RedirectToAction("Login", "Account");
        }


        [HttpPost]
        public async Task<IActionResult> Register(string username, string password)
        {
            var existingUser = await _userService.GetUserByUsernameAsync(username);
            if (existingUser != null)
            {
                ViewBag.ErrorMessage = "Nazwa użytkownika jest już zajęta.";
                return View();
            }

            var user = new User
            {
                Username = username,
                PasswordHash = password
            };

            await _userService.CreateUserAsync(user);
            return RedirectToAction("Login", "Home");
        }
        public async Task<IActionResult> Profile()
        {
            var username = HttpContext.Session.GetString("username");
            if (username == null) return RedirectToAction("Login");

            var user = await _userService.GetUserByUsernameAsync(username);

            var model = new EditProfileViewModel
            {
                Username = user.Username,
                Email = user.Email,
                FirstName = user.FirstName,
                LastName = user.LastName
            };

            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Profile(EditProfileViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            var user = await _userService.GetUserByUsernameAsync(model.Username);
            user.Email = model.Email;
            user.FirstName = model.FirstName;
            user.LastName = model.LastName;

            await _userService.UpdateUserAsync(user);

            ViewBag.Message = "Dane zapisane pomyślnie!";
            return View(model);
        }

    }
}
