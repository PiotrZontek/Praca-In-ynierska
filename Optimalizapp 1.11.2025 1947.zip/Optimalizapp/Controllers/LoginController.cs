﻿using Microsoft.AspNetCore.Mvc;
using Optimalizapp.Models;
using Optimalizapp.Services;
using System.Threading.Tasks;

namespace Optimalizapp.Controllers
{
    public class LoginController : Controller
    {
        // Prywatne pole przechowujące instancję serwisu użytkownika
        private readonly UserService _userService;

        // Konstruktor kontrolera, który przyjmuje UserService jako zależność (Dependency Injection)
        public LoginController(UserService userService)
        {
            _userService = userService;
        }

        // Metoda obsługująca żądanie GET dla strony logowania
        [HttpGet]
        public IActionResult Login()
        {
            return View(); // Zwraca widok strony logowania
        }

        // Metoda obsługująca żądanie POST dla logowania użytkownika
        [HttpPost]
        public async Task<IActionResult> Login(string username, string password)
        {
            // Sprawdzamy, czy model (dane wejściowe) są poprawne
            if (ModelState.IsValid)
            {
                // Próba uwierzytelnienia użytkownika za pomocą UserService
                var user = await _userService.AuthenticateAsync(username, password);
                if (user != null)
                {
                    return RedirectToAction("Dashboard", "Home"); // Przekierowanie do strony głównej po poprawnym logowaniu
                }

                // Jeśli dane logowania są niepoprawne, dodajemy komunikat o błędzie
                ModelState.AddModelError("", "Nieprawidłowy login lub hasło.");
            }

            return View(); // Jeśli logowanie się nie powiodło, ponownie wyświetlamy formularz logowania
        }
    }
}
