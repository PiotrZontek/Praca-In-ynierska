using Microsoft.AspNetCore.Mvc;
using Optimalizapp.Models;
using System.Diagnostics;

namespace Optimalizapp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            // TODO: Tu dodasz logik� sprawdzania u�ytkownika np. z bazy danych
            if (username == "admin" && password == "admin")
            {
                return RedirectToAction("Index"); // Po zalogowaniu przekierowanie na stron� g��wn�
            }

            ViewBag.ErrorMessage = "Nieprawid�owa nazwa u�ytkownika lub has�o.";
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
